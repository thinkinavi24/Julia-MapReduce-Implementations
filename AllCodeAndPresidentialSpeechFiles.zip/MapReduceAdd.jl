using BenchmarkTools
using CUDA
using FLoops
using FoldsCUDA 

#Our GPU

function myGPUReduce(range, s,f)
    i = (blockIdx().x-1) * blockDim().x + threadIdx().x
    if i <= length(range)
        CUDA.@atomic s[1] += f(range[i])
    end
    return
end

s = CuArray([0.0])
range = 1:100000000


#The below code represents the different things I tried and timed. I have commented it out since each section should be run at a time, rather than all of the code at once.

#f(x) = x^0.5

#f(n) = 1/n * (-1)^(n + 1) #Alternating harmonic sum. Tried both of these functiosn f

#@btime @cuda threads = min(1024, length(range)) blocks = cld(length(range), min(1024, length(range))) myGPUReduce(range, s, f)
#println(s)

#=
Timings for our GPU n = 10^1, 10^2, ..., 10^8:

6.561 us 
6.497 us
6.608 us
6.505 us
6.649 us
6.896 us 
6.525 us
65.323 ms
=#


#@btime FoldsCUDA.mapreduce(f, +, 1:100000000)

#= 

Timings for Julia FoldsCUDA GPU as n = 10^1, 10^2, ... , 10^8

62.372 ns
814.608 ns
29.387 us
485.004 us
5.222 ms
54.927 ms
626.515 ms
6.515 s
=#

