using MPI
using BenchmarkTools
#MPI.install_mpiexecjl()
#@btime begin
    MPI.Init()
    comm = MPI.COMM_WORLD
    rank = MPI.Comm_rank(comm)
    size = MPI.Comm_size(comm)

    dst = mod(rank+1, size)
    src = mod(rank-1, size)

    doc1 = "I want to test MapReduce"
    doc2 = "MapReduce is a cool algorithm to test."


#s1 = Array{String}
#s2 = Array{String}

    if rank == 0 #This conditional ensures only one send/receiving process
        s1 = split(lowercase.(replace(doc1, ['.', ',', '!', ';', '?', '(', ')', '[', ']'] => "")))
        Dict1 = Dict{String, Integer}()
        m = length(s1)
        values1 = zeros(Int(ceil((m + 1)/2)))
        for i in 1:m #count words in doc 1
            if s1[i] in keys(Dict1)
                Dict1[s1[i]] += 1
            else
                Dict1[s1[i]] = 1
            end
        end

        s1 = sort(s1) #sort words for easy reduce later
        MPI.Isend([Int(ceil((m + 1)/2))], dst, rank, comm) #send length of array of lengths of words
        lengths1 = zeros(Int(floor((m + 1)/2))) #initialize array for lengths of words

        for i in 0:Int(ceil((m - 1)/2))
            values1[i + 1] = Dict1[s1[m - i]] #populate values and lengths
            lengths1[i + 1] = length(s1[m - i])
            delete!(Dict1, s1[m - i]) #remove keys to avoid duplicates
        end

        MPI.Isend(lengths1, dst, rank + 1, comm)
        MPI.Isend(values1, dst, rank+2, comm) #send length and value arrays

        for i in 0:Int(ceil((m - 1)/2))
            MPI.Isend(Vector{Char}(s1[m - i]), dst, rank + i + 3, comm) #sending the words
        end

        #end of sending. Below is all receiving

        l = [0] 
        rreq = MPI.Irecv!(l, src, src + 5, comm)
        MPI.Waitall!([rreq])
        lengths2 = zeros(Int(l[1]))
        values2 = zeros(Int(l[1]))
        rreq1 = MPI.Irecv!(lengths2, src, src + 8, comm)
        rreq2 = MPI.Irecv!(values2, src, src + 9, comm)
        MPI.Waitall!([rreq1, rreq2])

        for i in 1:length(lengths2)
            msg = Array{Char}(undef, Int(lengths2[i]))
            rreqi = MPI.Irecv!(msg, src, src + i + 10, comm)
            MPI.Waitall!([rreqi])
            
            msg_string = String(msg)
            if msg_string in keys(Dict1) 
                Dict1[msg_string] += values2[i]
            else
                Dict1[msg_string] = values2[i]
            end
        end
        
    else
        s2 = split(lowercase.(replace(doc2, ['.', ',', '!', ';', '?', '(', ')', '[', ']'] => " "))) #remove punctuation so "dog." and "dog" are counted as the same word 
        Dict2 = Dict{String, Integer}()
        n = length(s2)
        values2 = zeros(Int(floor((n + 1)/2)))
        for i in 1:n
            if s2[i] in keys(Dict2)
                Dict2[s2[i]] += 1
            else
                Dict2[s2[i]] = 1
            end
        end

        s2 = sort(s2)

        MPI.Isend([Int(floor((n + 1)/2))], dst, rank + 5, comm)
        lengths2 = zeros(Int(floor((n + 1)/2)))

        for i in 1:Int((n + 1)/2)
            values2[i] = Dict2[s2[i]]
            lengths2[i] = length(s2[i])
            delete!(Dict2, s2[i])
        end

        MPI.Isend(lengths2, dst, rank + 8, comm)
        MPI.Isend(values2, dst, rank+9, comm)

        for i in 1:Int(floor((n + 1)/2))
            MPI.Isend(Vector{Char}(s2[i]), dst, rank + i + 10, comm)
        end

        l = [0]
        rreq = MPI.Irecv!(l, src, src, comm)
        MPI.Waitall!([rreq])
        lengths1 = zeros(Int(l[1]))
        values1 = zeros(Int(l[1]))
        rreq1 = MPI.Irecv!(lengths1, src, src + 1, comm)
        rreq2 = MPI.Irecv!(values1, src, src + 2, comm)
        MPI.Waitall!([rreq1, rreq2])

        for i in 1:length(lengths1)
            msg = Array{Char}(undef, Int(lengths1[i]))
            rreqi = MPI.Irecv!(msg, src, src + i + 2, comm)
            MPI.Waitall!([rreqi])
            
            msg_string = String(msg)
            if msg_string in keys(Dict2) 
                Dict2[msg_string] += values1[i]
            else
                Dict2[msg_string] = values1[i]
            end
        end
    end
    MPI.Barrier(comm)
#end
if rank == 0
    #println(Dict1)
else
    println(Dict2)
end

#Command to run code on juliahub: /home/jrun/data/.julia/bin/mpiexecjl -n 2 julia MPI_MapReduce_TwoProcesses.jl